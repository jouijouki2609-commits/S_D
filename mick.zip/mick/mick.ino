// ===================================================
// Projeto: Orbe das Joias do Infinito com Arduino
// Autor: MakerHero
// ===================================================

// === BIBLIOTECAS ===
// Bibliotecas nativas da IDE do Arduino
#include <SPI.h>
#include <Wire.h>

// Bibliotecas externas (devem estar instaladas)
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_NeoPixel.h>

// Notas musicais definidas em "pitches.h"
#include "pitches.h"

// === CONFIGURAÇÕES DO DISPLAY OLED ===
const byte TELA_LARGURA = 128;
const byte TELA_ALTURA = 32;
const int OLED_RESET = -1; // Nenhum pino utilizado para reset

Adafruit_SSD1306 display(TELA_LARGURA, TELA_ALTURA, &Wire, OLED_RESET);

// === PINOS E LED RGB ===
const int pinoSensor = 5;
const int pinoBuzzer = 4;
const int pinoLed = 6;
const int numLEDs = 8;

Adafruit_NeoPixel fitaLED(numLEDs, pinoLed, NEO_GRB + NEO_KHZ800);

// === DEFINIÇÃO DE CORES RGB ===
uint32_t azul    = fitaLED.Color(0, 0, 255);
uint32_t verde   = fitaLED.Color(0, 128, 0);
uint32_t amarelo = fitaLED.Color(218, 165, 32);
uint32_t branco  = fitaLED.Color(255, 255, 255);
uint32_t vermelho= fitaLED.Color(218, 0, 0);
uint32_t roxo    = fitaLED.Color(138, 43, 226);

// === VARIÁVEIS DE CONTROLE ===
bool vibrou = false;

volatile byte musica = 1;
volatile byte musicaTotal = 3;

volatile byte mensagem = 1;
volatile byte mensagemTotal = 3;

volatile byte cor = 1;
volatile byte corTotal = 6;

// === MÚSICAS ===
// "Come Get Your Love"
int come_get[] = {
  NOTE_E1, NOTE_B0, NOTE_A1, NOTE_E1, NOTE_B0, NOTE_A1,
  NOTE_E1, NOTE_E1, NOTE_B0, NOTE_A1, NOTE_E1, NOTE_B0, NOTE_A1
};
int duracao_come_get[] = {
  4, 8, 8, 4, 8, 4,
  8, 8, 8, 8, 8, 8, 8
};

// "Iron Man"
int iron_man[] = {
  NOTE_B5, NOTE_D5, NOTE_D5, NOTE_E5, NOTE_E5,
  NOTE_G5, NOTE_F5, NOTE_G5, NOTE_F5, NOTE_G5,
  NOTE_F5, NOTE_G5, NOTE_D5, NOTE_E5
};
int duracao_iron_man[] = {
  4, 4, 8, 8, 4,
  8, 16, 16, 16, 16, 8, 8, 8, 4
};

// "Pina Colada Song"
int pina_colada[] = {
  NOTE_F1, NOTE_A2, NOTE_G1, NOTE_F1,
  NOTE_D2, NOTE_C1, NOTE_G1, NOTE_D2, NOTE_G2,
  NOTE_F1, NOTE_A2, NOTE_G1, NOTE_F1,
  NOTE_D2, NOTE_C1, NOTE_G1, NOTE_D2, NOTE_G2
};
int duracao_pina_colada[] = {
  4, 4, 6, 2,
  4, 4, 6, 4, 2,
  4, 4, 6, 2,
  4, 4, 6, 4, 2
};

// === FUNÇÃO SETUP ===
void setup() {
  Serial.begin(9600);

  pinMode(pinoSensor, INPUT);
  pinMode(pinoBuzzer, OUTPUT);

  // Inicializa display OLED
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);

  // Inicializa fita de LED
  fitaLED.begin();
  fitaLED.show(); // Desliga todos os LEDs

  Serial.println("Unidade iniciando...");
}

// === FUNÇÃO LOOP ===
void loop() {
  // Detecta vibração
  if (digitalRead(pinoSensor) == HIGH) {
    Serial.println("Vibração detectada.");
    vibrou = true;
  }

  while (vibrou) {
    // === Mensagem no display OLED ===
    display.clearDisplay();
    display.setCursor(0, 20);
   
    if (mensagem == 1) {
      Serial.println("Mensagem 1: Quanto poder!");
      display.println("Quanto poder!");
    } else if (mensagem == 2) {
      Serial.println("Mensagem 2: Eson...");
      display.println("Eson...");
    } else {
      Serial.println("Mensagem 3: Que universo!");
      display.println("Que universo!");
    }

    display.display();
    display.startscrollleft(0x00, 0x07); // Scroll da mensagem

    // === Cor da fita LED ===
    fitaLED.clear();
    switch (cor) {
      case 1: Serial.println("LED: Branco");  fitaLED.fill(branco); break;
      case 2: Serial.println("LED: Verde");   fitaLED.fill(verde); break;
      case 3: Serial.println("LED: Vermelho");fitaLED.fill(vermelho); break;
      case 4: Serial.println("LED: Azul");    fitaLED.fill(azul); break;
      case 5: Serial.println("LED: Amarelo"); fitaLED.fill(amarelo); break;
      default:Serial.println("LED: Roxo");    fitaLED.fill(roxo); break;
    }
    fitaLED.show();

    // === Execução da música ===
    switch (musica) {
      case 1:
        Serial.println("Tocando: Come Get Your Love");
        tocarMusica(come_get, duracao_come_get, 13);
        break;
      case 2:
        Serial.println("Tocando: Iron Man");
        tocarMusica(iron_man, duracao_iron_man, 14);
        break;
      default:
        Serial.println("Tocando: Pina Colada Song");
        tocarMusica(pina_colada, duracao_pina_colada, 18);
        break;
    }

    // === Atualiza seletores para próxima interação ===
    musica = (musica % musicaTotal) + 1;
    mensagem = (mensagem % mensagemTotal) + 1;
    cor = (cor % corTotal) + 1;

    // Aguarda nova vibração
    vibrou = false;
  }
}

// === FUNÇÃO PARA TOCAR MÚSICAS ===
void tocarMusica(int* notas, int* duracoes, int tamanho) {
  for (int i = 0; i < tamanho; i++) {
    int duracaoNota = 1000 / duracoes[i] * 2;
    tone(pinoBuzzer, notas[i], duracaoNota);
    delay(duracaoNota * 1.30); // Pequena pausa entre notas
    noTone(pinoBuzzer);
  }
}

